﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("mi  segundo programa");

string sNombre;
string sEdad;
string sCarrera;
string sCarné;

Console.WriteLine("Coloque su nombre");
sNombre = Console.ReadLine();

Console.WriteLine("coloque su edad");
sEdad = Console.ReadLine();

Console.WriteLine("Coloque su carrera");
sCarrera = Console.ReadLine();

Console.WriteLine("Coloque su carné");
sCarné = Console.ReadLine();

Console.WriteLine("Nombre: " + sNombre);
Console.WriteLine("Edad: " + sEdad);
Console.WriteLine("Carrera: " + sCarrera)m
Console.WriteLine("Carné: " + sCarné);

Console.WriteLine("Soy " + sNombre + " tengo " + sEdad + " años y estudio la carrera de " + sCarrera + " mi número de cané es " + sCarné);


Console.ReadKey();



