﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("hola mundo");
Console.WriteLine("Soy Ana Cristina López ");

Console.Write("hola mundo");
Console.Write("soy Ana Crisitna López ");
Console.ReadKey();

/*que el writeLine deja un espacio entre linea y el Write no*/

Console.WriteLine("ingrese su nombre: ");
string Nombre = Console.ReadLine();
Console.WriteLine("hola mundo");
Console.WriteLine("soy " + Nombre);

/**/

Console.Write("hola mundo");
Console.Write("soy" + Nombre);
Console.ReadKey();