﻿// See https://aka.ms/new-console-template for more information

Console.WriteLine("tarea 1");

Console.WriteLine("ingrese la primera cantidad");
double cantidad1 = Convert.ToInt32(Console.ReadLine());
Console.WriteLine("ingrese 1 si la cantidad es en USD y 2 si la cantidad es en GTQ");
int moneda1 = Convert.ToInt32(Console.ReadLine());
if (moneda1 == 1)
    cantidad1=cantidad1 *7.83;

else if (moneda1 ==2)
    cantidad1 = cantidad1 *1;

Console.WriteLine("ingrese la segunda cantidad");
double cantidad2= Convert.ToInt32(Console.ReadLine());
Console.WriteLine("ingrese 1 si la cantidad es en USD y 2 si la cantidad es en GTQ");
int moneda2 = Convert.ToInt32(Console.ReadLine());
if (moneda2 == 1)
    cantidad2 = cantidad2 * 7.83;

else if (moneda2 == 2)
    cantidad2 = cantidad2 * 1;


Console.WriteLine("ingrese la tercera cantidad");
double cantidad3 = Convert.ToInt32(Console.ReadLine());
Console.WriteLine("ingrese 1 si la cantidad es en USD y 2 si la cantidad es en GTQ");
int moneda3 = Convert.ToInt32(Console.ReadLine());
if (moneda3 == 1)
    cantidad3 = cantidad3 * 7.83;

else if (moneda3 == 2)
    cantidad3 = cantidad3 * 1;



if (cantidad1<cantidad2)
{
    if (cantidad1<cantidad3)
    {
        Console.WriteLine(cantidad1);
    }
    else {
        Console.WriteLine(cantidad3);
   }

}
else{
    if (cantidad1<cantidad3)
    {
        Console.WriteLine(cantidad1);
    }
    else {
        Console.WriteLine(cantidad3);
   }

}



if (cantidad2 < cantidad1)
{
    if (cantidad2 < cantidad3)
    {
        Console.WriteLine(cantidad2);
    }
    else
    {
        Console.WriteLine(cantidad3);
    }

}
else
{
    if (cantidad2 < cantidad3)
    {
        Console.WriteLine(cantidad2);
    }
    else
    {
        Console.WriteLine(cantidad3);
    }

}


if (cantidad3<cantidad1)
{
    if (cantidad3<cantidad2)
    {
        Console.WriteLine(cantidad3);
    }
    else {
        Console.WriteLine(cantidad2);
   }

}
else{
    if (cantidad2<cantidad1)
    {
        Console.WriteLine(cantidad2);
    }
    else {
        Console.WriteLine(cantidad3);
   }

}
Console.ReadKey();

Console.Clear();

Console.WriteLine("Tarea 2");
Console.WriteLine("Ingresar monto a pagar");
double pagar = Convert.ToInt32(Console.ReadLine());
if (pagar < 0)
{
    Console.WriteLine("error");
}
else if (pagar <= 399.99)
{
    pagar = pagar;
    Console.WriteLine("El total a pagar es de " + pagar);
}
else if (pagar == 400)
{
    pagar = pagar - (pagar * 0.07);
    Console.WriteLine("El total a pagar es de " + pagar);
}
else if (pagar <= 1000)
{
    pagar = pagar - (pagar * 0.07);
    Console.WriteLine("El total a pagar es de " + pagar);
}
else if (pagar > 1000)
{
    pagar = pagar - (pagar * 0.10);
    Console.WriteLine("El total a pagar es de " + pagar);
}
else if (pagar <= 5000)
{
    pagar = pagar - (pagar * 0.10);
    Console.WriteLine("El total a pagar es de " + pagar);
}
else if (pagar > 5000)
{
    pagar = pagar - (pagar * 0.15);
    Console.WriteLine("El total a pagar es de " + pagar);
}
else if (pagar <= 15000)
{
    pagar = pagar - (pagar * 0.15);
    Console.WriteLine("El total a pagar es de " + pagar);
}
else if (pagar > 15000)
{
    pagar = pagar - (pagar * 0.25);
    Console.WriteLine("El total a pagar es de " + pagar);
}
Console.WriteLine("El cliente posee codigo de descuento, colocar 1 para si o 2 para no: ");
int t = Convert.ToInt32(Console.ReadLine());
if (t == 1)
{
    pagar = pagar - (pagar * 0.05);
    Console.WriteLine("El total a pagar es de " + pagar);
}
else if (t == 2)
{
    pagar = pagar;
    Console.WriteLine("El total a pagar es de " + pagar);

}
else if (t < 1)
{
    Console.WriteLine("Numero incorrecto");
}
else if (t > 2)
{
    Console.WriteLine("Numero incorrecto");
}
Console.ReadKey();
