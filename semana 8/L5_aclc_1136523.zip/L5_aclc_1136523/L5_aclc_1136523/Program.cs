﻿// See https://aka.ms/new-console-template for more information

Console.WriteLine("Ejercicio 1");
Console.WriteLine("Ingrese un número");
int numero;
numero = Convert.ToInt32(Console.ReadLine());

if (numero > 0)
    Console.WriteLine("el numero ingresado es positivo");
else if (numero < 0)
    Console.WriteLine("el numero ingresado es negativo");
else if (numero == 0)
    Console.WriteLine("el numero ingresado es igual a 0");


Console.ReadKey();

Console.Clear();

Console.WriteLine("Ejercicio 2");
Console.WriteLine("ingrese el numero de dia");
int día;
día = Convert.ToInt32(Console.ReadLine());

if (día == 1)
    Console.WriteLine("DIA: lunes");
else if (día == 2)
    Console.WriteLine("DIA: martes");
else if (día == 3)
    Console.WriteLine("DIA: miercoles");
else if (día == 4)
    Console.WriteLine("DiA:jueves");
else if (día == 5)
    Console.WriteLine("DIA. viernes");
else if (día == 6)
    Console.WriteLine("DIA: sábado");
else if (día == 7)
    Console.WriteLine("DIA: domingo");
else if (día < 0)
    Console.WriteLine("Error: El número ingresado debe estar entre 1 y 7");
else if (día > 7)
    Console.WriteLine("Error: El número ingresado debe estar entre 1 y 7");

Console.ReadKey();




