﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L9_ACLC1136523
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Automovil objAutomovil = new Automovil();

            Console.WriteLine("Ingrese los campos solicitados para el automóvil.");
            Console.Write("Modelo: ");
            int modelo = int.Parse(Console.ReadLine());

            Console.Write("Precio: ");
            double precio = double.Parse(Console.ReadLine());

            Console.Write("Marca: ");
            string marca = Console.ReadLine();

            Console.Write("Tipo de cambio: ");
            double tipoCambio = double.Parse(Console.ReadLine());

            objAutomovil.DefinirModelo(modelo);
            objAutomovil.DefinirPrecio(precio);
            objAutomovil.DefinirMarca(marca);
            objAutomovil.DefinirTipoCambio(tipoCambio);

            Console.WriteLine(objAutomovil.MostrarInformacion());

            Console.WriteLine("Cambie la disponibilidad del automóvil y muéstrela.");
            objAutomovil.CambiarDisponibilidad();
            Console.WriteLine(objAutomovil.MostrarDisponibilidad());

            Console.WriteLine("Ingrese un descuento y aplíquelo.");
            double descuento = double.Parse(Console.ReadLine());
            objAutomovil.AplicarDescuento(descuento);

            Console.WriteLine(objAutomovil.MostrarInformacion());

            Console.ReadLine(); // Para que la consola no se cierre inmediatamente
        }
    }

    public class Automovil
    {
        private int modelo;
        private double precio;
        private string marca;
        private bool disponible;
        private double tipoCambioDolar;
        private double descuentoAplicado;

        public Automovil()
        {
            modelo = 2019;
            precio = 10000.00;
            marca = "";
            disponible = false;
            tipoCambioDolar = 7.50;
            descuentoAplicado = 0.00;
        }

        public void DefinirModelo(int unModelo)
        {
            modelo = unModelo;
        }

        public void DefinirPrecio(double unPrecio)
        {
            precio = unPrecio;
        }

        public void DefinirMarca(string unaMarca)
        {
            marca = unaMarca;
        }

        public void DefinirTipoCambio(double unTipoCambio)
        {
            tipoCambioDolar = unTipoCambio;
        }

        public void CambiarDisponibilidad()
        {
            disponible = !disponible;
        }

        public string MostrarDisponibilidad()
        {
            return disponible ? "Disponible" : "No se encuentra disponible actualmente";
        }

        public string MostrarInformacion()
        {
            double precioEnDolares = precio / tipoCambioDolar;
            return $"Marca: {marca}. Modelo: {modelo}. Precio de venta: Q{precio}. Precio en dólares ${precioEnDolares}. {MostrarDisponibilidad()}";
        }

        public void AplicarDescuento(double miDescuento)
        {
            descuentoAplicado = miDescuento;
            double precioConDescuento = precio - descuentoAplicado;
            DefinirPrecio(precioConDescuento);
        }
    }
}
