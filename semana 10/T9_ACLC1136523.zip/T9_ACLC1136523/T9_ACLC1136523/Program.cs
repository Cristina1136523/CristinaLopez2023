﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T9_ACLC1136523
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Motocicleta objMotocicleta = new Motocicleta();

            // Solicitar datos al usuario
            Console.Write("Ingrese el modelo de la motocicleta: ");
            int modelo;
            while (!int.TryParse(Console.ReadLine(), out modelo))
            {
                Console.WriteLine("Por favor, ingrese un valor numérico para el modelo.");
                Console.Write("Ingrese el modelo de la motocicleta: ");
            }

            Console.Write("Ingrese la marca de la motocicleta: ");
            string marca = Console.ReadLine();

            Console.Write("Ingrese el precio de la motocicleta: ");
            double precio;
            while (!double.TryParse(Console.ReadLine(), out precio))
            {
                Console.WriteLine("Por favor, ingrese un valor numérico para el precio.");
                Console.Write("Ingrese el precio de la motocicleta: ");
            }

            Console.Write("Ingrese el porcentaje de IVA (entre 0.01 y 0.99): ");
            double iva;
            while (!double.TryParse(Console.ReadLine(), out iva) || iva < 0.01 || iva > 0.99)
            {
                Console.WriteLine("Por favor, ingrese un valor numérico entre 0.01 y 0.99 para el IVA.");
                Console.Write("Ingrese el porcentaje de IVA (entre 0.01 y 0.99): ");
            }

            objMotocicleta.DefinirPrecio(precio);
            objMotocicleta.DefinirIva(iva);

            Console.WriteLine("\nDatos de la motocicleta:\n" + objMotocicleta.MostrarDatos());
            Console.WriteLine("\nPrecio sin IVA: " + objMotocicleta.PrecioSinIva());
            Console.WriteLine("Precio con IVA: " + objMotocicleta.PrecioConIva());
            Console.WriteLine("Monto del IVA: " + objMotocicleta.DevolverIva());

            Console.ReadKey();

        }
    }

    class Motocicleta
    {
        private int modelo;
        private double precio;
        private string marca;
        private double iva;

        public Motocicleta()
        {
            modelo = 2019;
            precio = 1000;
            marca = "";
            iva = 0.12;
        }

        public string MostrarDatos()
        {
            return $"Modelo: {modelo}\nMarca: {marca}\nPrecio: {precio}\nIVA: {iva}";
        }

        public void DefinirPrecio(double nuevoPrecio)
        {
            precio = nuevoPrecio;
        }

        public void DefinirIva(double nuevoIva)
        {
            if (nuevoIva >= 0.01 && nuevoIva <= 0.99)
            {
                iva = nuevoIva;
            }
            else
            {
                Console.WriteLine("El valor del IVA debe estar entre 0.01 y 0.99");
            }
        }

        public double PrecioSinIva()
        {
            return precio;
        }

        public double PrecioConIva()
        {
            return precio + (precio * iva);
        }

        public double DevolverIva()
        {
            return precio * iva;
        }
    }
}
