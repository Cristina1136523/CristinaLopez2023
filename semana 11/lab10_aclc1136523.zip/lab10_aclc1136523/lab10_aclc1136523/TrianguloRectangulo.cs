﻿using System;


	public class TrianguloRectangulo
	{
        // Atributos privados
        private double catetoA;
        private double anguloOpuestoA;

        // Constructor
        public TrianguloRectangulo(double catetoA, double anguloOpuestoA)
        {
            this.catetoA = catetoA;
            this.anguloOpuestoA = anguloOpuestoA;
        }

        // Métodos públicos
        public double ObtenerCatetoA()
        {
            return catetoA;
        }

        public double ObtenerCatetoB()
        {
            // Implementa el cálculo del catetoB aquí
            return catetoA * Math.Tan(Math.PI / 180 * anguloOpuestoA);
        }

        public double ObtenerHipotenusa()
        {
            // Implementa el cálculo de la hipotenusa aquí
            return Math.Sqrt(Math.Pow(catetoA, 2) + Math.Pow(ObtenerCatetoB(), 2));
        }

        public double ObtenerAnguloOpuestoA()
        {
            return anguloOpuestoA;
        }

        public double ObtenerAnguloOpuestoB()
        {
            // El ángulo opuesto B es complementario a anguloOpuestoA
            return 90 - anguloOpuestoA;
        }

        public double ObtenerArea()
        {
            // Implementa el cálculo del área aquí
            return 0.5 * catetoA * ObtenerCatetoB();
        }
    
		}
	


