﻿using System;


	internal class Circulo
	{
        private double radio;

        public Circulo(double radio)
        {
            this.radio = radio;
        }

        private double ObtenerPerimetro()
        {
            return 2 * Math.PI * radio;
        }

        private double ObtenerArea()
        {
            return Math.PI * Math.Pow(radio, 2);
        }

        private double ObtenerVolumen()
        {
            return (4 * Math.PI * Math.Pow(radio, 3)) / 3;
        }

        public void CalcularGeometria(ref double unPerimetro, ref double unArea, ref double unVolumen)
        {
            unPerimetro = ObtenerPerimetro();
            unArea = ObtenerArea();
            unVolumen = ObtenerVolumen();
        }
   
		}
	


