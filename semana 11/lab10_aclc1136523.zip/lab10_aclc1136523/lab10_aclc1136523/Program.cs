﻿// See https://aka.ms/new-console-template for more information

    
        Console.Write("Ingrese el radio del círculo: ");
        double radioUsuario = Convert.ToDouble(Console.ReadLine());

       Circulo objCirculo = new Circulo(radioUsuario);

        double perimetro = 0.0;
        double area = 0.0;
        double volumen = 0.0;

        objCirculo.CalcularGeometria(ref perimetro, ref area, ref volumen);

        Console.WriteLine("Perímetro: " + perimetro);
        Console.WriteLine("Área: " + area);
        Console.WriteLine("Volumen: " + volumen);

        Console.ReadKey();

Console.Clear();
TrianguloRectangulo objTriangulo;

// Solicitar datos al usuario
Console.WriteLine("Ingrese la longitud del cateto del triángulo en metros:");
double longitudCateto = Convert.ToDouble(Console.ReadLine());

Console.WriteLine("Ingrese la amplitud en grados del ángulo opuesto al cateto:");
double anguloOpuesto = Convert.ToDouble(Console.ReadLine());

// Crear objeto TrianguloRectangulo con los datos ingresados
objTriangulo = new TrianguloRectangulo(longitudCateto, anguloOpuesto);

// Mostrar datos con formato adecuado
Console.WriteLine("\nDatos del triángulo rectángulo:");
Console.WriteLine($"a. Valor de cateto a: {objTriangulo.ObtenerCatetoA():F3} metros");
Console.WriteLine($"b. Valor de cateto b: {objTriangulo.ObtenerCatetoB():F3} metros");
Console.WriteLine($"c. Valor de hipotenusa: {objTriangulo.ObtenerHipotenusa():F3} metros");
Console.WriteLine($"d. Valor de ángulo opuesto de A: {objTriangulo.ObtenerAnguloOpuestoA():F3} grados");
Console.WriteLine($"e. Valor de ángulo opuesto de B: {objTriangulo.ObtenerAnguloOpuestoB():F3} grados");
Console.WriteLine($"f. Valor de área: {objTriangulo.ObtenerArea():F3} metros cuadrados");
Console.ReadKey();
        
