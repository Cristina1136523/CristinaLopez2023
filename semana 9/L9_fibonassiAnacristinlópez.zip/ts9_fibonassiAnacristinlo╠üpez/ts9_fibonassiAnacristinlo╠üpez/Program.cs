﻿// See https://aka.ms/new-console-template for more information
Console.Write("Ingrese un número para la serie de Fibonacci: ");
int n = Convert.ToInt32(Console.ReadLine());

Console.WriteLine("Serie de Fibonacci hasta {0}:", n);

MostrarSerieFibonacci(n);

Console.ReadLine(); 
        
        static void MostrarSerieFibonacci(int num)
{
    int a = 0, b = 1, c = 0;

    Console.Write("{0} {1} ", a, b);

    while (c <= num)
    {
        c = a + b;
        if (c <= num)
        {
            Console.Write("{0} ", c);
        }
        a = b;
        b = c;
    }
}



