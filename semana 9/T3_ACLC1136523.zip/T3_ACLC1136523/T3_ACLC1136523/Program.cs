﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T3_ACLC1136523
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Tarea No. 03");

            Console.Write("Ingrese un número entero mayor a 0 (n): ");
            if (int.TryParse(Console.ReadLine(), out int n) && n > 0)
            {
                Console.Write("Ingrese un número entero (x): ");
                if (int.TryParse(Console.ReadLine(), out int x))
                {
                    Console.Write("Ingrese un número entero (a): ");
                    if (int.TryParse(Console.ReadLine(), out int a))
                    {
                        double resultadoA = CalcularSerieA(n);
                        double resultadoB = CalcularSerieB(n);
                        double resultadoC = CalcularSerieC(x, a, n);

                        Console.WriteLine($"Resultado A: {resultadoA}");
                        Console.WriteLine($"Resultado B: {resultadoB}");
                        Console.WriteLine($"Resultado C: {resultadoC}");
                    }
                    else
                    {
                        Console.WriteLine("Ingrese un valor válido para 'a'.");
                    }
                }
                else
                {
                    Console.WriteLine("Ingrese un valor válido para 'x'.");
                }
            }
            else
            {
                Console.WriteLine("Ingrese un número entero mayor a 0 para 'n'.");
            }

            Console.ReadLine(); 
        }

        private static double CalcularSerieA(int n)
        {
            double resultado = 0;
            for (int i = 1; i <= n; i++)
            {
                resultado += 1.0 / i;
            }
            return resultado;
        }

        private static double CalcularSerieB(int n)
        {
            double resultado = 0;
            for (int i = 1; i <= n; i++)
            {
                resultado += 1.0 / Math.Pow(2, i);
            }
            return resultado;
        }

        private static double CalcularSerieC(int x, int a, int n)
        {
            double resultado = 0;
            for (int k = 0; k <= n; k++)
            {
                resultado += Math.Pow(x, a * k) / Math.Pow(n, k);
            }
            return resultado;
        }
    }
}
